function Maheshbabu()
    {
        document.getElementById("image").src="https://stat5.bollywoodhungama.in/wp-content/uploads/2023/06/Mahesh-Babu-2.jpg"
        document.getElementById("but1").style.backgroundColor ="red";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function NTR()
    {
        document.getElementById("image").src="https://english.cdn.zeenews.com/sites/default/files/2021/11/21/989453-jr-ntr.png"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="red";
        document.getElementById("but3").style.backgroundColor ="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Ram()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/16/1007/HD-wallpaper-ram-pothineni-deadlyking04-south-actor-thumbnail.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor ="red";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Hrithikroshan()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/151/816/HD-wallpaper-hrithik-roshan-actor-bollywood-handsome-hunk.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor ="green";
        document.getElementById("but4").style.backgroundColor ="red";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Surya()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/324/412/HD-wallpaper-surya-handsome-king.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="red";
        
        
    }

    function kohli()
    {
        document.getElementById("pic").src="https://4.bp.blogspot.com/-YZvsdozhc4k/V_zDXcH69TI/AAAAAAAALsA/pgfiG6yPPAY8fAybcOTQzIymyxs1JfF6gCLcB/s1600/13320142_1717711475157532_628169168_n.jpg";
        document.getElementById("btn1").style.backgroundColor="red";
        document.getElementById("btn2").style.backgroundColor="green";
        document.getElementById("btn3").style.backgroundColor="green";
        document.getElementById("btn4").style.backgroundColor="green";

    }
    function Rahul()
    {
        document.getElementById("pic").src="https://imagesvibe.com/wp-content/uploads/2022/12/KL-Rahul-Images7.jpg";
        document.getElementById("btn1").style.backgroundColor="green";
        document.getElementById("btn2").style.backgroundColor="red";
        document.getElementById("btn3").style.backgroundColor="green";
        document.getElementById("btn4").style.backgroundColor="green";

    }
    function Bumrah()
    {
        document.getElementById("pic").src="https://cdn.mygodimages.com/mygodimg/preview/jasprit-bumrah-balling-hd-wallpaper-photos-pic-11624985068v8v0fmxa1b.jpg";
        document.getElementById("btn1").style.backgroundColor="green";
        document.getElementById("btn2").style.backgroundColor="green";
        document.getElementById("btn3").style.backgroundColor="red";
        document.getElementById("btn4").style.backgroundColor="green";

    }
    function Dhoni()
    {
        document.getElementById("pic").src="https://assets.telegraphindia.com/telegraph/2023/Mar/1679785555_9835ab92bbc391f8dc816dac388c710c.gif";
        document.getElementById("btn1").style.backgroundColor="green";
        document.getElementById("btn2").style.backgroundColor="green";
        document.getElementById("btn3").style.backgroundColor="green";
        document.getElementById("btn4").style.backgroundColor="red";

    }
    function fun()
    {
        document.getElementById("demo").innerHTML="Ramya Chowdary";
        document.getElementById("demo").style.color="firebrick";
        document.getElementById("demo").style.backgroundColor="pink";
        document.getElementById("demo").style.fontWeight="bold";
        document.getElementById("button").style.backgroundColor="green";
        
    }

    function Onincrement()
    {   
        document.getElementById("countervalue").textContent;
        document.getElementById("countervalue")+1

    }

    function Onreset()
    {

    }

    function Ondecrement()
    {

    }