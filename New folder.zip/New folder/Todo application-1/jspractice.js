let x= myFunction(5,6);

  document.getElementById("demo").innerHTML= x;


 function myFunction(a,b)
 {
    return a*b;
 }



let Y = myFunction(1088,987);
document.getElementById("demo").innerHTML= Y;

function myFunction(r,c)
{
    return r-c;
}


let Z = myFunction(1088,98);
document.getElementById("demo").innerHTML= Z;

function myFunction(r,c)
{
    return r/c;
}