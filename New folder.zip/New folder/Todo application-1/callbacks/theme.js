// let bgContainerEl = document.getElementById("bgContainer");
// let headingEl = document.getElementById("heading");
// let themeUserInputEl = document.getElementById("themeUserInput");

// let lightThemeimgUrl =
//   "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png')";
// let darkThemeimgUrl =
//   "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png')";

// themeUserInputEl.addEventListener("keydown", function (event) {
//   if (event.key === "Enter") {
//     let themeUserInputVal = themeUserInputEl.value;
//     if (themeUserInputVal === "light") {
//       bgContainerEl.style.backgroundImage = lightThemeimgUrl;
//       headingEl.style.color = "#014d40";
//     } else if (themeUserInputVal === "dark") {
//       bgContainerEl.style.backgroundImage = darkThemeimgUrl;
//       headingEl.style.color = "#ffffff";
//     } else {
//       alert("Enter a valid theme");
//     }
//   }
// });

// function chanegeimage() {
//   let bgContainer1 = document.getElementById("bgContainer12");

//   bgContainer1.style.backgroundImage =
//     "url ('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png')";
// }

// const themeToggle = document.getElementById('theme-toggle');
// const container = document.querySelector('.container');
// const themeImage = document.getElementById('theme-image');

// themeToggle.addEventListener('change', () => {
//   container.classList.toggle('dark-mode');
//   if (container.classList.contains('dark-mode')) {
//     localStorage.setItem('theme', 'dark');
//     themeImage.src = 'https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png';
//   } else {
//     localStorage.setItem('theme', 'light');
//     themeImage.src = 'https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png'; 
//   }
// });

// // Check user's preferred theme from local storage
// const savedTheme = localStorage.getItem('theme');
// if (savedTheme === 'dark') {
//   container.classList.add('dark-mode');
//   themeToggle.checked = true;
//   themeImage.src = 'dark-image.jpg';


const themeToggle = document.getElementById("themeToggle");
const body = document.body;

themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-theme");
     
});