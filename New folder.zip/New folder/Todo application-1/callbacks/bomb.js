let defUserEl = document.getElementById("defUser");
let timerEl = document.getElementById("timer");

let counter = 10;
let uniqueId = setInterval(function () {
  let inputEl = defUserEl.value;
  counter = counter - 1;
  timerEl.textContent = counter;

  console.log(uniqueId);
  if (counter === 0) {
    timerEl.style.backgroundImage =
      "url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBV0sK7jqefIm4Vt3dvbQF3brC0qNd7XJ6OqIXa8Q1O7Qw0Z3fOr8qVwM6vrqK-ExtUuE&usqp=CAU')";
      timerEl.style.height="100vh"
      timerEl.style.backgroundSize="cover"

    clearInterval(uniqueId);
  } else if (inputEl === "ramya") {
    timerEl.textContent = "you did it!";
    clearInterval(uniqueId);
  }
}, 1000);
