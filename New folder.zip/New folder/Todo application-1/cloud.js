let wordCloud=["hello", "how", "what","youself", "name", "victory", "food", "beautiful","written", "awesome","where", "who","lovely"];
let wordContainerEl=document.getElementById("wordsContainer");
let userInputEl=document.getElementById("userInput");
let errorMsgEl=document.getElementById("errorMsg");
let errorMsg="please enter a word"


   function createAndAddWordCloud(word){
    let randomFontsize=Math.ceil(Math.random()*40)+"px";
    let wordEl=document.createElement("span");
    wordEl.textContent=word;
    wordEl.style.fontSize=randomFontsize;
    wordEl.classList.add("n-3");
    wordContainerEl.appendChild(wordEl);
   }
   function onAddWordToWordCloud(){  
     let userEnteredWord=userInputEl.value ;
        if(userEnteredWord !==""){
    userInputEl.value="";
    errorMsgEl.textContent="";
    createAndAddWordCloud(userEnteredWord);
    } else{
    errorMsgEl.textContent=errorMsg
    }
   }
   for(let word of wordCloud){
    onAddWordToWordCloud(word)
   }