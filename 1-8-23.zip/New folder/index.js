function Maheshbabu()
    {
        document.getElementById("image").src="https://stat5.bollywoodhungama.in/wp-content/uploads/2023/06/Mahesh-Babu-2.jpg"
        document.getElementById("but1").style.backgroundColor ="red";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function NTR()
    {
        document.getElementById("image").src="https://english.cdn.zeenews.com/sites/default/files/2021/11/21/989453-jr-ntr.png"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="red";
        document.getElementById("but3").style.backgroundColor ="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Ram()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/16/1007/HD-wallpaper-ram-pothineni-deadlyking04-south-actor-thumbnail.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor ="red";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Hrithikroshan()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/151/816/HD-wallpaper-hrithik-roshan-actor-bollywood-handsome-hunk.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor ="green";
        document.getElementById("but4").style.backgroundColor ="red";
        document.getElementById("but5").style.backgroundColor ="green";
        
        
    }
    function Surya()
    {
        document.getElementById("image").src="https://w0.peakpx.com/wallpaper/324/412/HD-wallpaper-surya-handsome-king.jpg"
        document.getElementById("but1").style.backgroundColor ="green";
        document.getElementById("but2").style.backgroundColor ="green";
        document.getElementById("but3").style.backgroundColor="green";
        document.getElementById("but4").style.backgroundColor ="green";
        document.getElementById("but5").style.backgroundColor ="red";
        
        
    }